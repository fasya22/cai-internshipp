<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('peserta', function (Blueprint $table) {
            $table->id();
            $table->uuid('uid');
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->string('nama')->nullable();
            $table->integer('jenis_kelamin')->comment('1 laki_laki; 2 perempuan')->nullable();
            $table->string('alamat')->nullable();
            $table->unsignedBigInteger('posisi_id')->nullable();
            $table->unsignedBigInteger('mentor_id')->nullable();

            $table->text('image')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->foreign('posisi_id')->references('id')->on('posisi')->onDelete('cascade');
            $table->foreign('mentor_id')->references('id')->on('mentor')->onDelete('cascade');
            $table->index('uid');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('peserta');
    }
};
