<?php

namespace App\Providers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;
use Carbon\Carbon;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot()
    {
        Blade::if('IsAdmin', function () {
            return Auth::user()->role_id == 0;
        });
        Blade::if('IsMentor', function () {
            return Auth::user()->role_id == 1;
        });
        Blade::if('IsPeserta', function () {
            return Auth::user()->role_id == 2;
        });

        config(['app.locale' => 'id']);
        Carbon::setLocale('id');
    }
}
