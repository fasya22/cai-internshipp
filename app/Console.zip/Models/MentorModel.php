<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class MentorModel extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = "mentor";
    protected $fillable = [
        'uid',
        'user_id',
        'nama',
        'jenis_kelamin',
        'posisi_id',
        'image',
        'created_at',
    ];
    protected $appends = ['posisi'];
    public function getPosisiAttribute()
    {
        if (array_key_exists('posisi_id', $this->attributes)) {
            $kat = DB::table('posisi')->select('posisi')->where('id', $this->attributes['posisi_id'])->first();
            if ($kat) {
                return $kat->posisi;
            }
        }

        return null;
    }

}