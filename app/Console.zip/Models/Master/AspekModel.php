<?php

namespace App\Models\Master;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class AspekModel extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = "aspek_penilaian";
    protected $fillable = [
        'uid',
        'aspek',
    ];

//     public function penilaian()
//     {
//         return $this->hasMany(Penilaian::class, 'faktor_id');
//     }

//     protected static function boot()
// {
//     parent::boot();

//     static::deleting(function ($faktor) {
//         // Update related penilaian when a faktor is deleted
//         PenilaianModel::updatePenilaianOnFaktorDelete($faktor);
//     });
// }
}
