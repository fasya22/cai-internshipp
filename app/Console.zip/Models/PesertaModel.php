<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class PesertaModel extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = "peserta";
    protected $fillable = [
        'uid',
        'user_id',
        'nama',
        'alamat',
        'jenis_kelamin',
        'posisi_id',
        'mentor_id',
        'image',
    ];

    protected $appends = ['posisi', 'mentor'];
    public function getPosisiAttribute()
    {
        if (array_key_exists('posisi_id', $this->attributes)) {
            $kat = DB::table('posisi')->select('posisi')->where('id', $this->attributes['posisi_id'])->first();
            if ($kat) {
                return $kat->posisi;
            }
        }

        return null;
    }
    public function getMentorAttribute()
    {
        if (array_key_exists('mentor_id', $this->attributes)) {
            $kat = DB::table('mentor')->select('nama')->where('id', $this->attributes['mentor_id'])->first();
            if ($kat) {
                return $kat->nama;
            }
        }

        return null;
    }
    
    public function mentor()
    {
        return $this->belongsTo(User::class, 'mentor_id', 'id');
    }


    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
