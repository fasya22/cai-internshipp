<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class LogbookModel extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = "logbook";
    protected $fillable = [
        'uid',
        'peserta_id',
        'tanggal',
        'aktivitas',
        // 'feedback',
        // 'status',
        'project_id',
    ];

    protected $appends = ['peserta', 'project'];
    public function getPesertaAttribute()
    {
        if (array_key_exists('peserta_id', $this->attributes)) {
            $kat = DB::table('peserta')->select('peserta')->where('id', $this->attributes['peserta_id'])->first();
            if ($kat) {
                return $kat->peserta;
            }
        }

        return null;
    }
    public function getProjectAttribute()
    {
        if (array_key_exists('project_id', $this->attributes)) {
            $kat = DB::table('project')->select('project')->where('id', $this->attributes['project_id'])->first();
            if ($kat) {
                return $kat->project;
            }
        }

        return null;
    }
}
