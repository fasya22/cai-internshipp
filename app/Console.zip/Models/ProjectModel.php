<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;

class ProjectModel extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected $table = "project";
    protected $fillable = [
        'uid',
        'peserta_id',
        'project',
    ];

    protected $appends = ['peserta'];
    public function getPesertaAttribute()
    {
        if (array_key_exists('peserta_id', $this->attributes)) {
            $peserta = DB::table('peserta')->select('nama')->where('id', $this->attributes['peserta_id'])->first();
            return $peserta ? (object)$peserta : null;
        }

        return null;
    }

    public function peserta()
    {
        return $this->belongsTo(PesertaModel::class, 'peserta_id');
    }
}
