<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\DB;
use App\Models\Master\AspekModel;

class PenilaianModel extends Model
{
    use HasFactory, SoftDeletes;
    protected $table = "penilaian";
    protected $fillable = [
        'uid',
        'peserta_id',
        'nilai',
        'total_nilai',
    ];

    protected $appends = ['peserta'];
    public function getPesertaAttribute()
    {
        if (array_key_exists('peserta_id', $this->attributes)) {
            $peserta = DB::table('peserta')->select('nama')->where('id', $this->attributes['peserta_id'])->first();
            return $peserta ? (object)$peserta : null;
        }

        return null;
    }

    public function getTotalNilaiAttribute()
{
    $nilaiArray = json_decode($this->attributes['nilai'], true);
    $aspeks = AspekModel::all();

    if (!empty($nilaiArray)) {
        $totalNilai = 0;

        foreach ($aspeks as $aspek) {
            if (array_key_exists($aspek->id, $nilaiArray)) {
                $totalNilai += $nilaiArray[$aspek->id];
            }
        }

        $average = $totalNilai / count($aspeks);
        $roundedAverage = number_format($average, 2);

        // Do not update the attribute here; it will be updated in the controller
        return $roundedAverage;
    }

    return 0;
}


    // public static function updatePenilaianOnAspekDelete($deletedAspek)
    // {
    //     // Get all penilaian records that have the deleted aspek
    //     $penilaians = self::whereJsonContains('nilai', $deletedAspek->id)->get();

    //     // Update total_nilai for each penilaian
    //     foreach ($penilaians as $penilaian) {
    //         $penilaian->updateTotalNilai();
    //     }
    // }

    public function updateTotalNilai()
    {
        // Calculate the total nilai and update the 'total_nilai' field
        $totalNilai = 0;
        $aspeks = AspekModel::all();

        foreach ($aspeks as $aspek) {
            $totalNilai += $this->{'aspek_' . $aspek->id};
        }

        $this->total_nilai = $totalNilai;
        // $this->save();
    }


    // public function getAspekAttribute()
    // {
    //     if (array_key_exists('aspek_id', $this->attributes)) {
    //         $kat = DB::table('aspek')->select('aspek')->where('id', $this->attributes['aspek_id'])->first();
    //         if ($kat) {
    //             return $kat->aspek;
    //         }
    //     }

    //     return null;
    // }
    public function peserta()
    {
        return $this->belongsTo(PesertaModel::class, 'peserta_id');
    }
    // public function aspek()
    // {
    //     return $this->belongsTo(AspekModel::class, 'aspek_id');
    // }
    // public function aspekToArray()
    // {
    //     $aspekArray = [];
    //     $aspekList = AspekModel::all();

    //     foreach ($aspekList as $aspek) {
    //         $aspekArray[] = $this->{'aspek_' . $aspek->id};
    //     }

    //     return $aspekArray;
    // }
}
