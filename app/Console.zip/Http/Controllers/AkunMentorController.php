<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MentorModel;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class AkunMentorController extends Controller
{
    public function index()
{
    $data['user_mntr'] = User::where('role_id', 1)->get();
    $data['mentor'] = MentorModel::whereNull('user_id')->get();
    // $data['mntr'] = (object) []; // Initialize $mntr variable as an object

    // // If 'id' parameter is present in the request, fetch the user data for the modal
    // if (request()->has('id')) {
    //     $id = request('id');
    //     $data['mntr'] = User::where('uid', $id)->first();
    // }

    return view('pages.mentor.akunmentor', $data);
}

    public function create()
    {
        
    }

    public function store(Request $request)
    {
    $validator = Validator::make($request->all(), [
        'mentor' => 'required',
        'username' => 'required',
        'email' => 'required|unique:users,email',
        'password' => 'required|min:8',
    ]);

    if ($validator->fails()) {
        return Redirect::back()->withErrors($validator);
    }

    $mntr = json_decode($request->mentor);

    $user = User::create([
        'name' => $request->username,
        'email' => $request->email,
        'password' => Hash::make($request->password),
        'uid' => Str::uuid(),
        'role_id' => 1,
    ]);

    MentorModel::where('uid', $mntr->uid)->update([
        'user_id' => $user['id']
    ]);

    return redirect('/user-mentor')->with('success', 'Berhasil tambah pengguna');
}

    public function show($id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
{
    // $data['mntr'] = User::where('uid', $id)->first();
    $data['mentor'] = MentorModel::get();
    $validator = Validator::make($request->all(), [
        'email' => [
            'required',
            Rule::unique("App\Models\User", 'email')->where(
                function ($query) use ($request) {
                    if ($request->userid) {
                        return $query
                            ->where('uid', '!=', $request->userid)
                            ->whereNull('deleted_at');
                    }

                    return $query
                        ->where('uid', $request->userid)
                        ->whereNull('deleted_at');
                }
            ),
        ],
        'mentor' => 'required',
        'username' => 'required',
        // 'password' => 'min:8',
    ]);

    if ($validator->fails()) {
        // return response()->json($validator->errors(), 400);
        return Redirect::back()->withErrors($validator);
    }
    $mntr = json_decode($request->mentor);
if ($request->mentor) {
    if ($request->password != null) {
        MentorModel::where('uid', $data['mntr']->uid)->update([
            'user_id' => null
        ]);
        User::where('uid', $id)->update([
            'name' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);
        MentorModel::where('uid', $data['mntr']->uid)->update([
            'user_id' => $request->id
        ]);
    } else {
        MentorModel::where('uid', $data['mntr']->uid)->update([
            'user_id' => null
        ]);
        User::where('uid', $id)->update([
            'name' => $request->username,
            'email' => $request->email,
            // 'password' => Hash::make($request->password),
        ]);
        MentorModel::where('uid', $data['mntr']->uid)->update([
            'user_id' => $request->id
        ]);
    }

    return redirect('/user-mentor')->with('success', 'Berhasil update data');
}
}
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        User::where('uid', $id)->delete();
        return redirect('/user-mentor');
    }
}
