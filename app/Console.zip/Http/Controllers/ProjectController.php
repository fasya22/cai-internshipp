<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ProjectModel;
use App\Models\PesertaModel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;

class ProjectController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

    // Mendapatkan informasi pengguna yang sedang login
    $user = Auth::user();

    // Jika pengguna yang login adalah mentor
    if ($user->role_id === 1) {
        $mentor_id = $user->mentor->id;
        // Mendapatkan peserta yang terkait dengan mentor yang sedang login
        $pesertas = PesertaModel::where('mentor_id', $mentor_id)->get();
        $projects = ProjectModel::with('peserta')->whereIn('peserta_id', $pesertas->pluck('id'))->get();
        
    }
    // Jika pengguna yang login adalah admin
    elseif ($user->role_id === 0) {
        $pesertas = PesertaModel::all();
        $projects = ProjectModel::with('peserta')->get();
    }
    // Jika pengguna yang login adalah peserta
    elseif ($user->role_id === 2) {
        // Mendapatkan peserta yang sedang login
        $pesertas = PesertaModel::where('user_id', $user->id)->get();
        // Mendapatkan proyek yang terkait dengan peserta yang sedang login
        $projects = ProjectModel::with('peserta')->whereIn('peserta_id', $pesertas->pluck('id'))->get();

    }

    return view('pages.project.project', compact('projects', 'pesertas'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'peserta' => 'required',
            'project' => 'required'
        ]);
    
        // Response error validation
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        ProjectModel::create([
            'uid' => Str::uuid(),
            'peserta_id' => $request->peserta,
            'project' => $request->project,
        ]);
        return redirect('/project')->with('success', 'Berhasil tambah data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validator = Validator::make($request->all(), [
            'peserta' => 'required',
            'project' => 'required'
        ]);

        // response error validation
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        ProjectModel::where('uid', $id)->update([
            'peserta_id' => $request->peserta,
            'project' => $request->project,
        ]);

        return redirect('/project')->with('success', 'Berhasil update data');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        ProjectModel::where('uid', $id)->delete();
        return redirect('/project');
    }
}
