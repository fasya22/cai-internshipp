<?php

namespace App\Http\Controllers;

use App\Models\Master\AspekModel;
use App\Models\PenilaianModel;
use App\Models\PesertaModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class PenilaianController extends Controller
{
    public function index()
    {
        $user = Auth::user(); // Assuming you're using Laravel's built-in authentication

        if ($user->role_id == 0) {
            // Admin: Retrieve all peserta
            $pesertas = PesertaModel::all();
            $penilaians = PenilaianModel::with('peserta')->get();
        } elseif ($user->role_id == 1) {
            // Mentor: Retrieve peserta based on mentor_id
            $mentor_id = $user->mentor->id;
            $pesertas = PesertaModel::where('mentor_id', $mentor_id)->get();
            $penilaians = PenilaianModel::with('peserta')->whereIn('peserta_id', $pesertas->pluck('id'))->get();
        } else {
            // Handle other roles if needed
            $pesertas = PesertaModel::where('user_id', $user->id)->get();
            $penilaians = PenilaianModel::with('peserta')->whereIn('peserta_id', $pesertas->pluck('id'))->get();
        }

        $aspeks = AspekModel::all();

        foreach ($penilaians as $penilaian) {
            $totalNilai = 0;

            foreach ($aspeks as $aspek) {
                // Ensure the aspek exists in the penilaian before accessing it
                if (property_exists($penilaian, 'aspek_' . $aspek->id)) {
                    $totalNilai += $penilaian->{'aspek_' . $aspek->id};
                }
            }

            $penilaian->update(['total_nilai' => $totalNilai]); // Update the total_nilai in the database
        }

        // $data['aspeks'] = AspekModel::all();
        // $data['pesertas'] = PesertaModel::all();
        // $data['penilaians'] = PenilaianModel::all();

        return view('pages.penilaian.penilaian', compact('penilaians', 'aspeks', 'pesertas'));
    }


    public function create()
    {
        //
    }

    // public function store(Request $request)
    // {
    //     $request->validate([
    //         'peserta_id' => 'required',
    //         'aspek_id' => 'required|exists:aspek,id',
    //         'nilai' => 'required|integer',
    //     ]);

    //     PenilaianModel::create($request->all());

    //     return redirect('/penilaian')->with('success', 'Berhasil tambah data');
    // }

    // public function store(Request $request)
    // {
    //     $request->validate([
    //         'peserta' => 'required', // Assuming the name attribute in the select field is 'peserta'
    //     ]);

    //     $pesertaId = $request->input('peserta');
    //     $aspeks = AspekModel::all();

    //     foreach ($aspeks as $aspek) {
    //         $request->validate([
    //             'aspek_' . $aspek->id => 'required|integer',
    //         ]);

    //         $nilai = $request->input('aspek_' . $aspek->id);

    //         // Save the data to the database
    //         PenilaianModel::create([
    //             'uid' => Str::uuid(),
    //             'peserta_id' => $pesertaId,
    //             'aspek_id' => $aspek->id,
    //             'nilai' => $nilai,
    //         ]);
    //     }

    //     return redirect('/penilaian')->with('success', 'Berhasil tambah data');
    // }

    public function store(Request $request)
{
    $request->validate([
        'peserta_id' => 'required',
        'nilai' => 'required|array',
    ]);

    // Create penilaian
    $penilaian = PenilaianModel::create([
        'uid' => Str::uuid(),
        'peserta_id' => $request->input('peserta_id'),
        'nilai' => json_encode($request->nilai), // Convert array to JSON
        'total_nilai' => 0, // Assuming total_nilai is initially set to 0
    ]);

    // Save nilai for each aspek (optional, depending on your structure)
    foreach ($request->input('nilai') as $aspekId => $nilai) {
        $penilaian->{'aspek_' . $aspekId} = $nilai;
    }

    // $penilaian->save();
    $penilaian->updateTotalNilai();

    return redirect('/penilaian')->with('success', 'Berhasil tambah data');
}




    public function show(Request $request, string $id)
    {
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
{
    $data['penilaian'] = PenilaianModel::where('uid', $id)->first();
    $data['aspeks'] = AspekModel::all();
    $data['pesertas'] = PesertaModel::all();
    // Validation rules
    $validator = Validator::make($request->all(), [
        'peserta_id' => 'required',
        'nilai' => 'required|array',
    ]);

    // Check if validation fails
    if ($validator->fails()) {
        return redirect()->back()->withErrors($validator)->withInput();
    }

    // Find the penilaian by UID
    $penilaian = PenilaianModel::where('uid', $id)->firstOrFail();

    // Update penilaian data
    $penilaian->peserta_id = $request->peserta_id;
    $penilaian->nilai = $request->nilai; // Assuming 'nilai' is JSON casted in the model
    $penilaian->save();

    // Save the changes to the database
    $penilaian->updateTotalNilai();

    return redirect('/penilaian')->with('success', 'Berhasil update data');
}



    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        PenilaianModel::where('uid', $id)->delete();
        return redirect('/penilaian');
    }
}
