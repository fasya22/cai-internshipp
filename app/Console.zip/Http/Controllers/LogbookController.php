<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\LogbookModel;
use App\Models\PesertaModel;
use App\Models\ProjectModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class LogbookController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $psrt = Auth::user()->peserta;
        $pesertaId = $psrt->id;

        $data['logbook'] = LogbookModel::leftJoin('peserta', 'peserta.id', '=', 'logbook.peserta_id')
            ->where('logbook.peserta_id', $pesertaId)
            ->get(['logbook.*', 'peserta.nama']);
        $data['idpeserta'] = $pesertaId;

        $aktivitasData = LogbookModel::orderBy('tanggal')->get();
        $aktivitasData = LogbookModel::where('peserta_id', Auth::user()->peserta->id)
            ->orderBy('tanggal')
            ->get();
        $groupedData = [];

        foreach ($aktivitasData as $aktivitas) {
            $groupedData[$aktivitas->tanggal][] = $aktivitas;
        }

        $data['project'] = ProjectModel::get();
        return view('pages.logbook.logbook', compact('groupedData'), $data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'tanggal' => 'required|date_format:Y-m-d',
            'project' => 'required',
            'aktivitas' => 'required',

        ]);

        // response error validation
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        LogbookModel::create([
            'uid' => Str::uuid(),
            'tanggal' => $request->tanggal,
            'project_id' => $request->project,
            'aktivitas' => $request->aktivitas,
            'peserta_id' => Auth::user()->peserta->id,
        ]);

        return redirect('/isi-logbook')->with('success', 'Berhasil isi Logbook');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validator = Validator::make($request->all(), [
            'tanggal' => 'required|date_format:Y-m-d',
            'project' => 'required',
            'aktivitas' => 'required',
            'progress' => 'required',
        ]);

        // response error validation
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        LogbookModel::where('uid', $id)->update([
            'tanggal' => $request->tanggal,
            'project_id' => $request->project,
            'aktivitas' => $request->aktivitas,
            'progress' => $request->progress,
        ]);

        return redirect('/isi-logbook')->with('success', 'Berhasil update data');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        LogbookModel::where('id', $id)->delete();
        return redirect('/isi-logbook')->with('success', 'Berhasil hapus data');
    }
}
