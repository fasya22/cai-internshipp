<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MentorModel;
use App\Models\Master\PosisiModel;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class MentorController extends Controller
{
    public function index()
    {
        $data['mentor'] = MentorModel::get();
        $data['posisi'] = PosisiModel::get();
        return view('pages.mentor.mentor', $data);
    }

    public function create()
    {
        
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'posisi',
            'nama' => 'required',
            'jenis_kelamin' => 'required',
            'foto' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);
    
        // Response error validation
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }
    
        // Cek apakah ada file foto yang diunggah
        if ($request->hasFile('foto')) {
            $name = $request->file('foto')->getClientOriginalName();
            $filename = time() . '-' . $name;
            $file = $request->file('foto');
            $file->move(public_path('Image'), $filename);
    
            MentorModel::create([
                'uid' => Str::uuid(),
                'posisi_id' => $request->posisi,
                'nama' => $request->nama,
                'jenis_kelamin' => $request->jenis_kelamin,
                'image' => $filename,
            ]);
        return redirect('/mentor')->with('success', 'Berhasil tambah data');
        } else {
            MentorModel::create([
                'uid' => Str::uuid(),
                'posisi_id' => $request->posisi,
                'nama' => $request->nama,
                'jenis_kelamin' => $request->jenis_kelamin,
            ]);
        }
    
        return redirect('/mentor')->with('success', 'Berhasil tambah data');
    
    }

    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        if ($request->hasFile('foto')) {
            $validator = Validator::make($request->all(), [
                'posisi',
                'nama' => 'required',
                'jenis_kelamin' => 'required',
                'foto' => 'image|mimes:jpeg,png,jpg|max:2048',
            ]);

            // response error validation
            if ($validator->fails()) {
                return Redirect::back()->withErrors($validator);
            }
            $name = $request->file('foto')->getClientOriginalName();
            $filename = time() . '-' . $name;
            $file = $request->file('foto');
            $file->move(public_path('Image'), $filename);

            MentorModel::where('uid', $id)->update([
                'posisi_id' => $request->posisi,
                'nama' => $request->nama,
                'jenis_kelamin' => $request->jenis_kelamin,
                'image' => $filename,

            ]);
            return redirect('/mentor')->with('success', 'Berhasil edit data Mentor');
        } else {
            $validator = Validator::make($request->all(), [
                'posisi',
                'nama' => 'required',
                'jenis_kelamin' => 'required',
            ]);
            if ($validator->fails()) {
                return Redirect::back()->withErrors($validator);
            }

            MentorModel::where('uid', $id)->update([
                'posisi_id' => $request->posisi,
                'nama' => $request->nama,
                'jenis_kelamin' => $request->jenis_kelamin,
            ]);
            return redirect('/mentor')->with('success', 'Berhasil edit data Mentor');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        MentorModel::where('uid', $id)->delete();
        return redirect('/mentor');
    }
}
