<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class JobController extends Controller
{
    /**
     * Display a listing of the resource.
     */

     public function applyJob(Request $request)
{
    // Simpan URL halaman saat ini ke dalam session
    session(['previous_url' => url()->current()]);

    // Periksa apakah pengguna telah login
    if (Auth::check()) {
        // Jika ya, arahkan ke halaman form aplikasi
        return view('front.pages.apply-job');
    } else {
        // Jika belum login, arahkan ke halaman login
        return redirect()->route('login');
    }
}

    public function index()
    {
        // session(['previous_url' => url()->current()]);
        // // Periksa apakah pengguna telah login dan memiliki peran sebagai peserta
        // if (Auth::check() && Auth::user()->role_id == 2) {
        //     // Jika ya, arahkan pengguna ke halaman form
        //     return view('front.pages.apply-job');
        // } else {
        //     // Jika belum login atau bukan peserta, arahkan pengguna ke halaman login
        //     return redirect()->route('login');
        // }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
