<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PesertaModel;
use App\Models\MentorModel;
use App\Models\Master\PosisiModel;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class PesertaController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        // $data['peserta'] = PesertaModel::whereHas('user', function ($query) {
        //     $query->where('role_id', 2);
        // })->get();
        $user = Auth::user();

        if ($user->role_id == 1) {
            // Jika user memiliki role mentor
            $data['peserta'] = PesertaModel::where('mentor_id', $user->mentor->id)->get();
        } else {
            // Jika user bukan mentor, tampilkan semua data peserta
            $data['peserta'] = PesertaModel::get();
        }

        $data['posisi'] = PosisiModel::get();
        $data['mentor'] = MentorModel::get();
        return view('pages.peserta.peserta', $data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'nama',
            'jenis_kelamin',
            'alamat',
            'posisi',
            'mentor',
            'foto' => 'image|mimes:jpeg,png,jpg|max:2048',
        ]);
    
        // Response error validation
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }
    
        // Cek apakah ada file foto yang diunggah
        if ($request->hasFile('foto')) {
            $name = $request->file('foto')->getClientOriginalName();
            $filename = time() . '-' . $name;
            $file = $request->file('foto');
            $file->move(public_path('Image'), $filename);

            PesertaModel::create([
                'uid' => Str::uuid(),
                'nama' => $request->nama,
                'jenis_kelamin' => $request->jenis_kelamin,
                'alamat' => $request->alamat,
                'posisi_id' => $request->posisi,
                'mentor_id' => $request->mentor,
                'image' => $filename,
            ]);
            return redirect('/peserta')->with('success', 'Berhasil tambah data');
        } else {
            PesertaModel::create([
                'uid' => Str::uuid(),
                'nama' => $request->nama,
                'jenis_kelamin' => $request->jenis_kelamin,
                'alamat' => $request->alamat,
                'posisi_id' => $request->posisi,
                'mentor_id' => $request->mentor,
            ]);
        }
        return redirect('/peserta')->with('success', 'Berhasil tambah data');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $data['peserta'] = PesertaModel::where('uid', $id)->first();
        $data['posisi'] = PosisiModel::get();
        $data['mentor'] = MentorModel::get();
        if ($request->hasFile('foto')) {
            $validator = Validator::make($request->all(), [
                'nama',
                'jenis_kelamin',
                'alamat',
                'posisi',
                'mentor',
                'foto' => 'image|mimes:jpeg,png,jpg|max:2048',
            ]);

            // response error validation
            if ($validator->fails()) {
                return Redirect::back()->withErrors($validator);
            }
            $name = $request->file('foto')->getClientOriginalName();
            $filename = time() . '-' . $name;
            $file = $request->file('foto');
            $file->move(public_path('Image'), $filename);

            PesertaModel::where('uid', $id)->update([
                'nama' => $request->nama,
                'jenis_kelamin' => $request->jenis_kelamin,
                'alamat' => $request->alamat,
                'posisi_id' => $request->posisi,
                'mentor_id' => $request->mentor,
                'image' => $filename,
            ]);
            return redirect('/peserta')->with('success', 'Berhasil edit data Peserta');
        } else {
            $validator = Validator::make($request->all(), [
                'nama',
                'jenis_kelamin',
                'alamat',
                'posisi',
                'mentor',
            ]);
            if ($validator->fails()) {
                return Redirect::back()->withErrors($validator);
            }

            PesertaModel::where('uid', $id)->update([
                'nama' => $request->nama,
                'jenis_kelamin' => $request->jenis_kelamin,
                'alamat' => $request->alamat,
                'posisi_id' => $request->posisi,
                'mentor_id' => $request->mentor,
            ]);

        return redirect('/peserta')->with('success', 'Berhasil update data');
    }
}

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        PesertaModel::where('uid', $id)->delete();
        return redirect('/peserta');
    }
}
