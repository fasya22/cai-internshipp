<?php

namespace App\Listeners;

use App\Models\PesertaModel;
use Illuminate\Auth\Events\Registered;

class CreateUserPeserta
{
    /**
     * Handle the event.
     *
     * @param  Registered  $event
     * @return void
     */
    public function handle(Registered $event)
    {
        // Cek apakah pengguna memiliki role 2 (peserta)
        if ($event->user->role_id == 2) {
            // Tambahkan entri ke tabel peserta
            PesertaModel::create([
                'uid' => \Illuminate\Support\Str::uuid(), // Berikan nilai 'uid' dengan UUID yang unik
                'user_id' => $event->user->id,
                // Tambahkan kolom lain jika perlu
                'nama' => null, 
                'jenis_kelamin' => null, 
                'alamat' => null,
                'posisi_id' => null,
                'mentor_id' => null,
                'image' => null,
            ]);
        }
    }
}
